app/template role
Process and parse OpenShift template and create dynamic inventory hosts for each resource object.
